/*
This is empty on purpose! Your code to build the resume will go here.
 */

// Website Title
$("title").text("Stefano Monteiro | Front-End Developer");

// bio

// bio Object
var bio = {
    "name": "Stefano Monteiro",
    "role": "Front-End Web Developer",
    "contacts": {
        "mobile": "+506 8459-5556",
        "email": "ste_bm@hotmail.com",
        "github": "stefanomonteiro",
        "twitter": "@ste_bm",
        "location": "Costa Rica"
    },
    "welcomeMessage": "MBA in Business/Marketing at University of Wales. Fluent in English and in Spanish. Experienced in commercial management, in planning and development of strategic tasks. Also experienced in customer relationship and in recruiting, supervision and management of people. Knowledge of strategic and operational activities within a company. Ability in surveys and analytics evaluations of data and theoretical concepts. Execution of promotional campaigns and staff training. ",
    "skills": [
        "Programing", "HTML", "CSS", "JavaScript"
    ],
    "biopic": "images/headshot.jpg"
};

// bio DOM manipulation


bio.display = function() {

    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    // bio.contact
    var mobile = bio.contacts.mobile;
    var formattedMobile = HTMLmobile.replace("%data%", mobile);
    var email = bio.contacts.email;
    var formattedEmail = HTMLemail.replace("%data%", email);
    var github = bio.contacts.github;
    var formattedGithub = HTMLgithub.replace("%data%", github);
    var twitter = bio.contacts.twitter;
    var formattedTwitter = HTMLtwitter.replace("%data%", twitter);
    var location = bio.contacts.location;
    var formattedLocation = HTMLlocation.replace("%data%", location);

    var formattedMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    var formattedBiopic = HTMLbioPic.replace("%data%", bio.biopic);

    $("#header").prepend(formattedName, formattedRole);
    $("#header").append("<div id='pic-message'></div>");
    $("#pic-message").append(formattedBiopic, formattedMessage);
    $("#pic-message").css({
        "margin-bottom": 25,
        "margin-top": 20
    });
    $("#topContacts, #footerContacts").append(formattedMobile, formattedEmail, formattedGithub, formattedTwitter, formattedLocation);

    //Skils
    if (bio.skills.length > 0) {
        $("#header").append(HTMLskillsStart);

        for (i = 0; i < bio.skills.length; i++) {

            var formattedSkills = HTMLskills.replace("%data%", bio.skills[i]);
            $("#skills").append(formattedSkills);
        }
    }


};
bio.display();


// Changing Skills Class - So it displays horizontally

$("#skills").toggleClass("flex-box flex-column");


//Education


//Education Object

var education = {
    "schools": [{
            "name": "University of Wales",
            "location": "London",
            "degree": "MBA",
            "majors": ["Marketing"],
            "dates": "2009-2010",
            "url": "http://www.wales.ac.uk/"
        },
        {
            "name": "Mackenzie University",
            "location": "Sao Paulo",
            "degree": "BA",
            "majors": ["Business"],
            "dates": "2001-2006",
            "url": "http://portal.mackenzie.br/"
        }
    ],
    "onlineCourses": [{
            "title": "Front-End Web Developer Nanodegree",
            "school": "Udacity",
            "dates": "May 2017",
            "url": "http://www.udacity.com"
        },
        {
            "title": "Front End Web Development Certification",
            "school": "FreeCodeCamp",
            "dates": "May 2017",
            "url": "http://www.freecodecamp.com"
        }

    ]
};

// Education DOM Manipulation

education.display = function() {
    for (var i = 0; i < education.schools.length; i++) {

        $("#education").append(HTMLschoolStart);


        var formattedschoolName = HTMLschoolName.replace("%data%", education.schools[i].name).replace("#", education.schools[i].url);
        var formattedLocation = HTMLschoolLocation.replace("%data%", education.schools[i].location);
        var formattedDegree = HTMLschoolDegree.replace("%data%", education.schools[i].degree);
        var formattedDates = HTMLschoolDates.replace("%data%", education.schools[i].dates);
        var formattedMajors = HTMLschoolMajor.replace("%data%", education.schools[i].majors);
        var formattedUrl = HTMLschoolURL.replace("%data%", education.schools[i].url);


        $(".education-entry:last").append(formattedschoolName + formattedDegree);
        $(".education-entry:last").append(formattedLocation, formattedDates, formattedMajors);
    }

    $("#education").append(HTMLonlineClasses);


    for (var ii = 0; ii < education.onlineCourses.length; ii++) {

        $("#education").append(HTMLschoolStart);

        var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", education.onlineCourses[ii].title).replace("#", education.onlineCourses[ii].link);
        var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[ii].school);
        var formattedOnlineDate = HTMLonlineDates.replace("%data%", education.onlineCourses[ii].dates);
        var formattedOnlineLink = HTMLonlineURL.replace("%data%", education.onlineCourses[ii].url).replace("#", education.onlineCourses[ii].url);

        $(".education-entry:last").append(formattedOnlineTitle + formattedOnlineSchool);
        $(".education-entry:last").append(formattedOnlineDate, formattedOnlineLink);

    }

};
education.display();

//Work

//Work Object

var work = {
    "jobs": [{
            "employer": "Trissie.com",
            "title": "E-Commerce Director",
            "location": "Sao Paulo, Brazil",
            "dates": "2012",
            "description": "- Responsible for planning the layout and the follow up whilst the website´s development, also responsible for operational and administrative planning as well as the branding strategies.; - Experienced in E-commerce platforms analysis, in identify and target the potential clients on Social Medias and also experienced in research and analysis of comparison websites.; - Knowledge of website hosting, SEO, Google Analytics, Google Adwords and Social Medias, including Facebook Power Editor.;"
        },
        {
            "employer": "Swimming Nature LTD",
            "title": "Managing Director",
            "location": "London, UK",
            "dates": "2009-2011",
            "description": "- Coordination, planning and control of all administrative activities, financial resources and marketing strategies.; - Execution of promotional campaigns, negotiating space at medias and developing and acquiring the material to be used.; -Responsible for contacting customers at the pre and post selling, explaining the product and solving problems, aiming to acquire and retain the customers.;"
        }
    ]
};

// Work DOM Manipulation

work.display = function() {
    for (var i = 0; i < work.jobs.length; i++) {

        // create a new element for each job

        $("#workExperience").append(HTMLworkStart);

        // format the data

        var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[i].employer);
        var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[i].title);
        var formattedLocation = HTMLworkLocation.replace("%data%", work.jobs[i].location);
        var formattedDates = HTMLworkDates.replace("%data%", work.jobs[i].dates);

        $(".work-entry:last").append(formattedEmployer + formattedTitle);
        $(".work-entry:last").append(formattedLocation, formattedDates, HTMLworkDescription);

        // Create <li> for Job Descriptions

        var listItems = work.jobs[i].description.split(";");

       $(".work-entry:last ul").each(function(){

            for (var j = 0; j < listItems.length; j++){
        var formattedDescription = HTMLworkDescriptionList.replace("%data%", listItems[j]);
        $(this).append(formattedDescription);
            }
       });

    }
};
work.display();

//<li> font size CSS

$("li").css("font-size", 14);

//Projects

//Projects Object

var projects = [{
        "title": "My Portfolio",
        "link": "My-Portifolio/My_Portifolio.html",
        "dates": "May 2017",
        "description": "Project Overview: For this project, you'll be building a portfolio website. You will be provided a design mockup as a PDF-file, and you must replicate that design in HTML and CSS. You will develop a responsive website that will display images, descriptions and links to each of the portfolio projects you will complete through the course of your Nanodegree program. Please note that while you should aim to recreate the mockup, you may also use your own custom images to personalize this project. Once you've successfully replicated the design mockup, you are encouraged to continue tweaking and making customizations to the design to personalize it and make it your own! This is your living portfolio site, so make sure you're happy with it.",
        "images": ["images/my-portfolio.jpg", "images/My_Portfolio-After.jpg"]
    },
    {
        "title": "Animal Card",
        "link": "animal-card/card.html",
        "dates": "May 2017",
        "description": "Project Overview: Are you starting to feel like a web developer yet? You should! Before you move on, I have one more challenge. I want you to use what you've learned up to this point to complete the following project. Simply titled, 'Animal Trading Cards', this project combines the skills you mastered in the problem set and asks you to re-create a webpage from a design prototype. This is a common workflow for front-end web developers. Typically, you'll be provided with a design prototype that needs to be translated to an actual, functional website. In most cases, designers only provide you with the design prototype. However, for this project, I've provided you with the design prototype and the HTML. The design prototype used in this project is inspired by trading cards and features a fish you might recognize from a popular animated film. You’ll be creating the card and swapping out the fish with an animal of your choice.",
        "images": ["images/animal-card.jpg", "images/Animal_Trading_Cards-After.jpg"]
    }
];


//Projects DOM Manipulation

projects.display = function() {
    for (var i = 0; i < projects.length; i++) {

        $("#projects").append(HTMLprojectStart);

        var formattedTitle = HTMLprojectTitle.replace("%data%", projects[i].title).replace("#", projects[i].link);
        var formattedDates = HTMLprojectDates.replace("%data%", projects[i].dates);
        var formattedDescription = HTMLprojectDescription.replace("%data%", projects[i].description);
        $(".project-entry:last").append(formattedTitle, formattedDates, formattedDescription);

        for (var j = 0; j < projects[i].images.length; j++){
            var formattedImages = HTMLprojectImage.replace("%data%", projects[i].images[j]);
            $(".project-entry:last").append(formattedImages);
        }
    }
};
projects.display();



// Google MAP

$("#mapDiv").append(googleMap);



// Internationalize Names


function inName(name) {
    name = name.split(" ");
    name[1] = name[1].toUpperCase();
    name[0] = name[0].slice(0, 1).toUpperCase() + name[0].slice(1).toLowerCase();
    return name[0] + " " + name[1];

}

$("#main").append(internationalizeButton);


//Quiz: Collecting Click Locations

$(document).click(function(loc) {
    // your code goes here
    var x = loc.pageX;
    var y = loc.pageY;

    logClicks(x, y);
});


// NavBar

// NavBar Brand

var formattedBrand = HTMLnavbarBrand.replace("%data%", bio.name).replace("#", "#main");

// NavBar Items
var navBar = {
    "One": "Bio",
    "Two": "Work",
    "Three": "Projects",
    "Four": "Education",
    "Five": "Map",
    "Six": "Contact Me"
};

// Adding Bio to Dropdown Menu
var mobile = bio.contacts.mobile;
var formattedMobile = HTMLmobile.replace("%data%", mobile);
var email = bio.contacts.email;
var formattedEmail = HTMLemail.replace("%data%", email);
var github = bio.contacts.github;
var formattedGithub = HTMLgithub.replace("%data%", github);
var twitter = bio.contacts.twitter;
var formattedTwitter = HTMLtwitter.replace("%data%", twitter);


var formattedNavbarBio = HTMLnavbarEachItem.replace("%data%", navBar.One).replace("#", "#name");
var formattedNavbarWork = HTMLnavbarEachItem.replace("%data%", navBar.Two).replace("#", "#workExperience");
var formattedNavbarProjects = HTMLnavbarEachItem.replace("%data%", navBar.Three).replace("#", "#projects");
var formattedNavbarEducation = HTMLnavbarEachItem.replace("%data%", navBar.Four).replace("#", "#education");
var formattedNavbarMap = HTMLnavbarEachItem.replace("%data%", navBar.Five).replace("#", "#mapDiv");

var formattedNavbarDropdownLink = HTMLnavbarDropdownLink.replace("%data%", navBar.Six);
var formattedNnavbarDropDownItemMobile = HTMLnavbarDropDownItem.replace("%data%", formattedMobile);
var formattedNnavbarDropDownItemEmail = HTMLnavbarDropDownItem.replace("%data%", formattedEmail);
var formattedNnavbarDropDownItemGitHub = HTMLnavbarDropDownItem.replace("%data%", formattedGithub);
var formattedNnavbarDropDownItemTwitter = HTMLnavbarDropDownItem.replace("%data%", formattedTwitter);

$("#main").prepend(HTMLnavbarTags);
$("nav").append(HTMLnavbarDiv);
$("div.container").append(HTMLnavbarButton, formattedBrand, HTMLnavbarLScreen);
$("#navbarNavAltMarkup").append(HTMLnavbarItems);
$(".navbar-nav").append(formattedNavbarBio, formattedNavbarWork, formattedNavbarProjects, formattedNavbarEducation, formattedNavbarMap, HTMLnavbarDropdown);
$(".dropdown").append(formattedNavbarDropdownLink, HTMLnavbarDropdownMenu);
$(".dropdown-menu").append(formattedNnavbarDropDownItemMobile, formattedNnavbarDropDownItemEmail, formattedNnavbarDropDownItemGitHub, formattedNnavbarDropDownItemTwitter);

//DropDown Menu CSS

$(".dropdown-item span.white-text").toggleClass("white-text").css("color", "#484848");
$(".dropdown-menu").css("left", -150);




// Role

$("#header").children("span").first().css({
    "padding-left": "15px",
    "color": "#fff"
});

//<hr>

$("hr").css("border-top", "1px solid #f5ae23");

// Images max-width

$("img").css("max-width", "100%");


// Contacts


// Adding icons

var icons = {
    "mobile": "fa fa-phone",
    "email": "fa fa-envelope",
    "github": "fa fa-github",
    "twitter": "fa fa-twitter",
    "location": "fa fa-globe"
};

icons.display = function() {


    $("ul#topContacts li.flex-item").prepend("<i aria-hidden=\"true\"></i>");

    $("ul#topContacts li.flex-item").each(function() {

        addIcons = $(this).find("span.orange-text").text();

        $(this).find("i").addClass(icons[addIcons]).css("color", "#f5a623");


    });

    $(".dropdown-item .flex-item").prepend("<i aria-hidden=\"true\"></i>");

    $(".dropdown-item .flex-item").each(function() {

        addIcons = $(this).find("span.orange-text").text();

        $(this).find("i").addClass(icons[addIcons]).css("color", "#f5a623");


    });

    $("ul#footerContacts li.flex-item").prepend("<i aria-hidden=\"true\"></i>");

    $("ul#footerContacts li.flex-item").each(function() {

        addIcons = $(this).find("span.orange-text").text();

        $(this).find("i").addClass(icons[addIcons]).css("color", "#f5a623");


    });




};
icons.display();



// Adjusting Padding and Spacing Elements

$("#workExperience h2, #education h2, #projects h2, #mapDiv h2").css("padding-top", 65);
$("#mapDiv").css("margin-bottom", 130);
$(".education-entry, .work-entry, .project-entry").css("padding", "2% 5%");
$(".navbar-brand").css("margin-right", 150);



function setPadding() { // Download correct padding-top when page is loaded

    if ($(window).width() > 1200) {
        $("#header").css("padding-top", "6%");
    } else if ($(window).width() > 900) {
        $("#header").css("padding-top", "8%");
    } else if ($(window).width() > 650) {
        $("#header").css("padding-top", "10%");
    } else if ($(window).width() > 550) {
        $("#header").css("padding-top", "12%");
    } else if ($(window).width() > 450) {
        $("#header").css("padding-top", "14%");
    } else {
        $("#header").css("padding-top", "20%");
    }
}

setPadding();

$(window).resize(function() { // Download correct padding-top when screen is resized
    setPadding();
});


// Add Attribute Target to <a>

$(".education-entry a, .project-entry a").attr("target", "_blank");











